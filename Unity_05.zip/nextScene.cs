using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGmaeButton : MonoBehaviour
{
/*    public void ChangeFirstScene()
    {
        SceneManager.LoadScene("SampleScene");
    }*/
    public void ChangeSecondScene()
    {
        SceneManager.LoadScene("copy");
    }
}
